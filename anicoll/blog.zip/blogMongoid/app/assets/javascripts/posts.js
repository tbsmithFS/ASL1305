$(function(){
  $('.new_post').on('ajax:success', render_new_post_form);
  $('.new_post').on('ajax:error', error_render_new_post_form);
  console.log($('.new_post'));

  function render_new_post_form(event, data, status, xhr){
    console.log('data:', data , status, xhr);
    $('.new_post').hide();
    $(data).insertAfter('.new_post');
  }  
  function error_render_new_post_form(event, xhr, status, error){
    console.log('error :' , error);
  }
});
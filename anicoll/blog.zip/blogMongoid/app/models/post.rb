# defines what a post is and its relationships
class Post
  include Mongoid::Document
  include Mongoid::Timestamps
  field :name,     type: String
  field :category, type: String
  field :title,    type: String
  field :content,  type: String
  embeds_many :comments
end

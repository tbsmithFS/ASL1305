$(function(){

	/*
	==============================================
	=============GLOBAL VARIABLES=================
	==============================================
 	*/

	var doc = $(document),
	h=window.innerHeight - 50;
	var page = 1;
	var imageHeight = $('.image').outerHeight();
 	var moveHeight = imageHeight * 4;
 	var max = ($('.numImages').attr('value') - 1) / 8;
	$('.hero').css({height:h});
	var fi = $('.image:first').attr('data-si');

	$('.uploaded_img').css('background-image', 'url(' + fi + ')');

 	/*
	==============================================
	=================FUNCTIONS====================
	==============================================
 	*/

 	function displayPhone(si) {
 		$('.lgimg').css('background-image', 'url(' + si + ')');
 	}

 	/*
	==============================================
	==============EVENT LISTENERS=================
	==============================================
 	*/

 	doc.on('click','.left', function(e){
 		var image = document.querySelectorAll('.lgimg');
 		var	pixelMargin = parseInt(image.style.marginLeft, 10);
 		num = 10;
 		pixelMargin += num;
 		image.style.marginLeft = pixelMargin.toString() + 'px';
 	});

 	doc.on('click','.image',function(){
 		var si = $(this).attr('data-si');
 		$('.image').css({borderColor:'#fff'});
 		$(this).css({borderColor:'red'});
 		displayPhone(si);
 	});

 	doc.on('click', '#next', function(){
 		if(page < max){
 			$('#slider').animate({
		    	top: '-=' + moveHeight
			}, 1000, 'easeOutQuint');
			page += 1;
 		}
 	});

 	doc.on('click', '#previous', function(){
 		if ( page > 1 ) {
	 		$('#slider').animate({
			    top: '+=' + moveHeight
			}, 1000, 'easeOutQuint');
			page -= 1;
 		}
 	});

});

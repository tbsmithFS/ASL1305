<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Orders extends CI_Controller {

	public function placeorder() {
		$this->load->view('order');
	}
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
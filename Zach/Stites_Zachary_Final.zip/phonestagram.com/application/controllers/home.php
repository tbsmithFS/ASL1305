<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{

		require '../application/third_party/instagram.class.php';
		require '../application/third_party/instagram.config.php';

		$igdata = $this->session->userdata('data');
			
		if(!empty($igdata))
		{
			$data=$igdata;
			$instagram->setAccessToken($data);

			$view = array(
						'username' => $data->user->username,
						'name' => $data->user->full_name,
						'userId' => $data->user->id,
						'images' => $instagram->getUserMedia($data->user->id)
						);

			$this->load->view('home',$view);

			// echo '<img src='.$data->user->profile_picture.'><br />';
			// echo 'Name:' . $data->user->full_name . '<br />';
			// echo 'Username:' .$data->user->username . '<br />';
			// echo 'User ID:' .$data->user->id . '<br />';
			// echo 'Bio:' .$data->user->bio . '<br />';
			// echo 'Website:' .$data->user->website . '<br />';
			// echo 'Profile Pic:' .$data->user->profile_picture . '<br />';
			// echo 'Access Token:' .$data->access_token . '<br />';

			//HOMEPAGE

			//END HOMEPAGE

			//Store user access token
			// $instagram->setAccessToken($data);

		}
		else
		{
			$data = array('loginUrl' => $instagram->getLoginUrl());
			$this->load->view('home',$data);
		}
	}


	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
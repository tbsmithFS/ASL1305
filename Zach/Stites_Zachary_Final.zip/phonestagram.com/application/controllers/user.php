<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller {

	public function index()
	{
		$this->load->view('home');
	}

	public function success() {

		require '../application/third_party/instagram.class.php';
		require '../application/third_party/instagram.config.php';

		// Recieve OAuth code parameter
		$code = $_GET['code'];

		// Check whether the user has granted access
		if (true === isset($code))
		{

			// Recieve OAuth token object
			$data = $instagram->getOAuthToken($code);

			$this->session->set_userdata('data',$data);

			$testToken = $data->access_token;
			// Verify user details in USERS table
			$query=$this->db->get_where('instagram_users',array('instagram_access_token'=>$testToken));
			if($query->num_rows() == 0)
			{	
				// Storing instagram user data into session
				$id=$data->user->id;
				$user=$data->user->username;
				$fullname=$data->user->full_name;
				$bio=$data->user->bio;
				$website=$data->user->website;
				$token=$data->access_token;
				// Inserting values into USERS table
				mysql_query("insert into instagram_users(username,Name,Bio,Website,instagram_id,instagram_access_token) 
					values('$user','$fullname','$bio','$website','$id','$token')");
			}


			//Store user access token
			$instagram->setAccessToken($data);




			
			// Redirecting you home.php
			header('Location: /');

		}
		else
		{
			// Check whether an error occured
			if(true === isset($_GET['error']))
			{
				echo 'An error occured: '.$_GET['error_description'];
			}
		}
	}
	
}

?>
<?php 
	$instagram = new Instagram(array(
		'apiKey' => 'b560a1573f3e40d3bd74a22ae5f3fc6b', //Client_ID
		'apiSecret' => '971168982fb0483bb2344da34bb8ed77', //Client_Secret
		'apiCallback' => 'http://phonestagram.com/user/success' //Callback URL
	));
?>
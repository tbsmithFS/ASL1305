<?php 
	if(isset($username)) {
		$isloggedin = TRUE;
	}else{
		$isloggedin = FALSE;
	}
?>
<!doctype html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="assets/main.css">
	<link href='http://fonts.googleapis.com/css?family=Handlee' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow' rel='stylesheet' type='text/css'>
	<title>Phonestagram | Custom Instagramed phone cases</title>
</head>
<body>
	<header>
		<img src="assets/images/logo.png" alt="" id="logo">
		<ul>
			<li class="nav_li">Home</li>
			<li class="nav_li">Products</li>
			<li class="nav_li">Features</li>
			<li class="nav_li"><?php if($isloggedin == TRUE){ echo $username; }else{ echo "Log In"; } ?></li>
			<li class="nav_li create_li">Create</li>
		</ul>
	</header>
	<div class="hero">

		<div class="hero_bar"></div>
	</div>
	<div class="main_content">
		<div class="clearfix"></div>
		<aside>
			<?php if($isloggedin == TRUE) { ?>
			
				<div class="iglogin">
					<img src="assets/images/igicon.png" alt="" id="igicon">
					<p class="iglogin_text" >Currently logged in!</p>
				</div>

			<?php } else { ?>

			<a href="<?php if($isloggedin == TRUE){echo "#";}else{ echo $loginUrl; } ?>" class="iglogin_anchor">
				<div class="iglogin">
					<img src="assets/images/igicon.png" alt="" id="igicon">
					<p class="iglogin_text">Login with Instagram</p>
				</div>
			</a>

			<?php } ?>
			<a href="#" class="selectdevice_anchor">
				<div class="selectdevice">
					<img src="assets/images/iphoneicon.png" alt="" id="iphoneicon">
					<p class="selectdevice_text">Select Device</p>
				</div>
			</a>
			<a id="previous" class="loadless_anchor">
				<div class="loadless">
					<img src="assets/images/previous.png" alt="" class="refreshicon">
				</div>
			</a>
			<div class="photoalbum">

				<div id="slider" style="position:relative">


				<?php if($isloggedin == TRUE) { 

					$popular = $images;
					foreach ($popular->data as $data) {
						// Storing standard-image in data-si attribute. This can be called on jquery .on to change phones bg
						echo '<img src="' .$data->images->thumbnail->url.'" data-si="' . $data->images->standard_resolution->url . '" class="image">' . "\n";
					}

					echo '<input type="hidden" name="numImages" value="' . sizeof($popular->data) . '" class="numImages">';

				} ?>

				</div>

			</div>
			<a id="next" class="loadmore_anchor">
				<div class="loadmore">
					<img src="assets/images/next.png" alt="" class="refreshicon">
				</div>
			</a>
		</aside>
			<?php if($isloggedin == TRUE) { ?>
				<div class="blank"></div>
				<img src="assets/images/left.png" alt="" id="left" class="left">
			<?php }else{ ?>
			<div class="hints">
				<img src="assets/images/hint1.png" alt="" id="hint1" class="hinter">
				<img src="assets/images/hint2.png" alt="" id="hint2">
				<img src="assets/images/hint3.png" alt="" id="hint3">
			</div>
			<?php } ?>
		<div class="template">
			<div class="uploaded_img">
				<div class="lgimg">
					<div class="shadow">
						<div class="window">

						</div>
					</div>
				</div>
			</div>
		</div>
		<?php if($isloggedin == TRUE) { ?>
		<img src="assets/images/right.png" alt="" id="right" class="right">
		<?php } ?>
		<div class="checkout_block">
			<?php if($isloggedin == TRUE) { ?>

				<h1>Hey <?php $name = preg_replace("/ .*/", "", $name); echo $name;?>,</h1>
				<p>Hope you are enjoying your experience with us! Feel free
				to play around a bit and experiment with your favorite photos.
		  		Once you decide on one you like, just click on the button below.</p>
			<?php }else{ ?>
				<h1>Hi there.</h1>
				<p>Hope you are enjoying your experience with us! Feel free
				to play around a bit and experiment with your favorite photos.
		  		Once you decide on one you like, just click on the button below.</p>
			<?php } ?>

			<a href="/orders/placeorder" class="checkout_button">
				<img src="/assets/images/checkout.png" alt="checkout">
			</a>

		</div>
		<div class="clearfix"></div>
	</div>
	<footer></footer>
	 <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
	 <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
	 <script type="text/javascript" src="/main.js.php"></script>

</body>
</html>
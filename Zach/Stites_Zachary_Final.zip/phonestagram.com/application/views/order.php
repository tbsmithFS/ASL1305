<!doctype html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="/assets/main.css">
	<link href='http://fonts.googleapis.com/css?family=Handlee' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow' rel='stylesheet' type='text/css'>
	<title>Phonestagram | Custom Instagramed phone cases</title>
</head>
<body>
	<header>
		<img src="/assets/images/logo.png" alt="" id="logo">
		<ul>
			<li class="nav_li">Home</li>
			<li class="nav_li">Products</li>
			<li class="nav_li">Features</li>
			<li class="nav_li create_li">Create</li>
		</ul>
	</header>

	<div class="orderform_wrapper">
		<div class="clearfix"></div>
		<div class="user_info">

		</div>
		<div class="user_receipt">

		</div>
		<div class="clearfix"></div>
	</div>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
	<script type="text/javascript" src="/main.js.php"></script>

</body>
</html>
<?php
	class AppController extends Controller {

		public $components = array(
	        'Session',
	        'Auth' => array(
	            'loginRedirect' => array('controller' => 'posts', 'action' => 'index'),
	            'logoutRedirect' => array('controller' => 'pages', 'action' => 'display', 'home'),
	            'authError'=>"You can't access that page",
	            'authorize' => array('Controller')
	        )
	    );

	    public function isAuthorized($user) {
		    // Admin can access every action
		    // if (isset($user['role']) && $user['role'] === 'admin') {
		    //     return true;
		    // }

		    // Default deny
		    return true;
		}

		public function beforeFilter() {
	        $this->Auth->allow('index', 'view');
	    }
	}
